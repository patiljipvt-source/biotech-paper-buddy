from fastapi import FastAPI, UploadFile, File, Query
from fastapi.middleware.cors import CORSMiddleware
from typing import List
from utils.extract import extract_text_from_pdf
from utils.query import ask_question, search_web
import os

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/upload/")
async def upload_file(file: UploadFile = File(...)):
    content = await file.read()
    with open("temp.pdf", "wb") as f:
        f.write(content)
    extracted_text = extract_text_from_pdf("temp.pdf")
    return {"text": extracted_text}

@app.get("/ask/")
async def ask(text: str = Query(...), question: str = Query(...)):
    answer = ask_question(text, question)
    return {"answer": answer}

@app.get("/search-papers/")
async def search_papers(query: str = Query(...)):
    results = search_web(query)
    return {"results": results}
