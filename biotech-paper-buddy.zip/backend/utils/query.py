import requests

def ask_question(text, question):
    return f"Mock answer to '{question}' based on provided text."

def search_web(query):
    # In real use, this would call arXiv or Semantic Scholar
    return [{"title": "Sample Paper 1", "url": "https://arxiv.org/abs/1234.5678"}]
