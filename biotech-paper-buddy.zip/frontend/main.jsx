import ReactDOM from "react-dom/client";

const App = () => {
  return <div>Hello from Biotech Paper Buddy</div>;
};

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
